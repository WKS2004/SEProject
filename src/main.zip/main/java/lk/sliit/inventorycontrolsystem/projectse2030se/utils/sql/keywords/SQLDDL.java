package lk.sliit.inventorycontrolsystem.projectse2030se.utils.sql.keywords;

interface SQLDDL {

    String CREATE = "CREATE";
    String ALTER  = "ALTER";
    String DROP   = "DROP";
    String TRUNCATE = "TRUNCATE";
    String ADD = "ADD";
    String RENAME = "RENAME";
    String TABLE  = "TABLE";
    String COLUMN = "COLUMN";

}
