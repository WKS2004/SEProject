package lk.sliit.inventorycontrolsystem.projectse2030se.DAO;

import lk.sliit.inventorycontrolsystem.projectse2030se.models.Payment;

public interface PaymentDAO extends GeneralDAO<Payment> {
}
