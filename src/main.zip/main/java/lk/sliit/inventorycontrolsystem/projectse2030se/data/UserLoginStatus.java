package lk.sliit.inventorycontrolsystem.projectse2030se.data;

public enum UserLoginStatus {
    LOGIN_SUCCESS,

    INVALID_CREDENTIALS,

    NOT_REGISTERED;
}
