package lk.sliit.inventorycontrolsystem.projectse2030se.utils.sql.keywords;

public interface SQLKeywords
        extends SQLDML, SQLDDL, SQLClauses, SQLJoins, SQLConstraints, SQLFunctions, SQLTypes, SQLDataTypes {}
