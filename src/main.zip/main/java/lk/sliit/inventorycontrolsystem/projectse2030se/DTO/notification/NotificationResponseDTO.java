package lk.sliit.inventorycontrolsystem.projectse2030se.DTO.notification;

public record NotificationResponseDTO() {
}
