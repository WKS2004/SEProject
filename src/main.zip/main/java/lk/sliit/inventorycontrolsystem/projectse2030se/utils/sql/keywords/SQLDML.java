package lk.sliit.inventorycontrolsystem.projectse2030se.utils.sql.keywords;

interface SQLDML {

    String SELECT = "SELECT";
    String INSERT = "INSERT";
    String UPDATE = "UPDATE";
    String DELETE = "DELETE";
    String MERGE  = "MERGE";
    String CALL   = "CALL";
    String EXPLAIN = "EXPLAIN";
    String LOCK = "LOCK";

}
