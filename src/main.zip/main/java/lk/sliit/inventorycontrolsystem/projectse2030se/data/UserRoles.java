package lk.sliit.inventorycontrolsystem.projectse2030se.data;

public enum UserRoles {
    OWNER,
    SYSTEM_ADMIN,
    INVENTORY_MANAGER,
    WAREHOUSE_MANAGER,
    SALES_MANAGER,
    SUPPLIER,
    CUSTOMER;
}
