package lk.sliit.inventorycontrolsystem.projectse2030se.DTO.course;

import lk.sliit.inventorycontrolsystem.projectse2030se.DAO.CourseDAO;
import lk.sliit.inventorycontrolsystem.projectse2030se.DAO.jdbc.CourseDAOJdbc;
import lk.sliit.inventorycontrolsystem.projectse2030se.models.Course;

import java.time.LocalDateTime;

public record CourseRequestUpdateDTO(String id, LocalDateTime createdAt, LocalDateTime updatedAt, String name, String code, String description, int durationMinutes, double price, String level, boolean courseStatus) {

    private static final CourseDAO courseDAO = new CourseDAOJdbc();

    public Course toCourse() {
        Course course = courseDAO.getById(id);

        if (course != null) {
            course.setName(name);
            course.setCode(code);
            course.setDescription(description);
            course.setDurationMinutes(durationMinutes);
            course.setPrice(price);
            course.setLevel(level);
            course.setCourseStatus(courseStatus);
        }

        return course;
    }
}
