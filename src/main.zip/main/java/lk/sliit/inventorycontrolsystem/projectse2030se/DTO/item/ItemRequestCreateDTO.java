package lk.sliit.inventorycontrolsystem.projectse2030se.DTO.item;

public record ItemRequestCreateDTO() {
}
