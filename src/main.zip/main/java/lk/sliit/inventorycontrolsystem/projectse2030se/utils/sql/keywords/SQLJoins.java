package lk.sliit.inventorycontrolsystem.projectse2030se.utils.sql.keywords;

interface SQLJoins {

    String JOIN = "JOIN";
    String INNER_JOIN = "INNER JOIN";
    String LEFT_JOIN = "LEFT JOIN";
    String RIGHT_JOIN = "RIGHT JOIN";
    String FULL_JOIN = "FULL JOIN";
    String CROSS_JOIN = "CROSS JOIN";
    String ON = "ON";
    String USING = "USING";

}
