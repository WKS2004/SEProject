package lk.sliit.inventorycontrolsystem.projectse2030se.utils.sql.keywords;

public interface OtherSymbols {

}
