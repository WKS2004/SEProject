package lk.sliit.inventorycontrolsystem.projectse2030se.utils;

public interface SQLQueryHandlerUtils {

//    static String sqlQueryMaker(String... allArgs) {
//        StringBuilder finalQuery = new StringBuilder(allArgs[0]);
//        for (int counter = 1; counter < allArgs.length; counter++) {
//            finalQuery.append(" ").append(allArgs[counter]);
//        }
//
//        return finalQuery.toString();
//    }

}
