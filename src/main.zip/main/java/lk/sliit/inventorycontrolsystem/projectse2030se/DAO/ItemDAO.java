package lk.sliit.inventorycontrolsystem.projectse2030se.DAO;

import lk.sliit.inventorycontrolsystem.projectse2030se.models.Item;

public interface ItemDAO extends GeneralDAO<Item> {
}
